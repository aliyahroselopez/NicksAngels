package com.csb.appadvc.finalproject.NicksAngelsParsells.model;


import com.csb.appadvc.finalproject.NicksAngelsParsells.dto.ProductDTO;

import javax.persistence.*;

@Entity
@Table(name = "prod")
public class Product {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long ID;

    @Column(nullable = false)
    private String prodName;

    @Column(nullable = false)
    private String category;

    @Column(nullable = false)
    private int stock;

    @Column(nullable = false)
    private float price;

    @Column(nullable = false)
    private Byte avail;

    public Product() {}

    public Product(Long ID) {
        this.ID = ID;
    }

    public Product(ProductDTO productDTO) {
        this.ID = productDTO.getID();
        this.prodName = productDTO.getProdName();
        this.category = productDTO.getCategory();
        this.stock = productDTO.getStock();
        this.price = productDTO.getPrice();
        this.avail = productDTO.getAvail();
    }

    public Long getID() { return ID; }

    public String getProdName() { return prodName; }

    public String getCategory() { return category; }

    public int getStock() { return stock; }

    public float getPrice() { return price; }

    public Byte getAvail() { return avail; }
}
