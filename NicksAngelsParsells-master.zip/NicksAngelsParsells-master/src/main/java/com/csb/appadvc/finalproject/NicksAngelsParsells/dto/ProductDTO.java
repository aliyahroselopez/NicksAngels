package com.csb.appadvc.finalproject.NicksAngelsParsells.dto;

import com.csb.appadvc.finalproject.NicksAngelsParsells.model.Product;
import java.util.*;
public class ProductDTO {

    private Long ID;

    private String prodName;

    private String category;

    private int stock;

    private Float price;

    private byte avail;

    public ProductDTO() {}

    public ProductDTO(int prodID, String prodName, String category, int stock, Float price, byte avail){
        this.ID = ID;
        this.prodName = prodName;
        this.category = category;
        this.stock = stock;
        this.price = price;
        this.avail = avail;
    }

    public ProductDTO(Product product){
        this.ID = product.getID();
        this.prodName = product.getProdName();
        this.category = product.getCategory();
        this.stock = product.getStock();
        this.price = product.getPrice();
        this.avail = product.getAvail();
    }



    public Long getID() { return ID; }

    public void setID(int prodID) { this.ID = ID; }

    public String getProdName() { return prodName; }

    public void setProdName(String prodName) { this.prodName = prodName; }

    public String getCategory() { return category; }

    public void setCategory(String category) { this.category = category; }

    public int getStock() { return stock; }

    public void setStock(int stock) { this.stock = stock; }

    public Float getPrice() { return price; }

    public void setPrice(Float price) { this.price = price; }

    public byte getAvail() { return avail; }

    public void setAvail(byte avail) { this.avail = avail; }


}