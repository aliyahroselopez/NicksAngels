package com.csb.appadvc.finalproject.NicksAngelsParsells.repository;

import com.csb.appadvc.finalproject.NicksAngelsParsells.model.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Long>{
}
